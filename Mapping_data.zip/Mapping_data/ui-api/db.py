"""
These API keys are temporary and will be stored in a database when
we get an auth system created. This is just so we can secure our API
from random bot requests.
"""

api_keys = {
    "MM-XzlyDYbpgSmiYFKtoPEqkZLbBz7cP2": "41518562-924c-4f49-800d-85c078589f76",
    "MM-HZ1KGGGxZjjNXaePX8Q5kBP6aYllP8": "527d37c8-2d92-4e5f-8790-0b0fc88f0952",
    "MM-fHMAuu1OsywfnEuPvx0b9jyKMyO7qy": "92cf6a64-f443-407a-b6a9-514ab00e63e2",
}

users = {
    "41518562-924c-4f49-800d-85c078589f76": {"name": "Isaac"},
    "527d37c8-2d92-4e5f-8790-0b0fc88f0952": {"name": "Akram"},
    "92cf6a64-f443-407a-b6a9-514ab00e63e2": {"name": "Kiran"},
}


def check_api_key(api_key: str):
    return api_key in api_keys


def get_user_from_api_key(api_key: str):
    return users[api_keys[api_key]]
