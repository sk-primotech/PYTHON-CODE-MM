from pydantic import BaseModel, Field
from typing import List, Optional
from bson import ObjectId

class ObjectIdStr(str):
    @classmethod
    def __get_validators__(cls):
        yield cls.validate

    @classmethod
    def validate(cls, v):
        if not ObjectId.is_valid(v):
            raise ValueError("Invalid ObjectId")
        return str(v)

class ClusteredPoint(BaseModel):
    ManufacturerId: int
    ManufacturerCatalogNumber: str
    ItemDescription: str
    Group: Optional[str] = None
    Company: Optional[str] = None
    Business: Optional[str] = None
    Division: Optional[str] = None
    Therapy: Optional[str] = None
    Specialty: Optional[str] = None
    Anatomy: Optional[str] = None
    SubAnatomy: Optional[str] = None
    ProductCategory: Optional[str] = None
    ProductFamily: Optional[str] = None
    Model: Optional[str] = None
    embedding: int
    fuzzy: int
    Total: int

class InputData(BaseModel):
    ManufacturerId: int
    ManufacturerCatalogNumber: str
    ItemDescription: str
    tinker: str
    category_flag: str
    Clustered_points: List[ClusteredPoint]
