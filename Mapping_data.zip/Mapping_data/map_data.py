import argparse
import certifi
import logging
import multiprocessing
import os
from time import sleep, time
import numpy as np
import openai
from openai import OpenAI
import pandas as pd
import pyodbc
import torch
from dotenv import load_dotenv
from rapidfuzz import fuzz
from sentence_transformers import SentenceTransformer
from utils import (
    check_db_conn,
    get_gudid_data,
    get_mapping_tables,
    get_tickers,
    get_unmapped_data,
    insert_dataframe_into_sql,
    insert_matches_into_mongodb,
    setup_logging,
    get_current_directory,
)

client = OpenAI(api_key=os.environ.get("OPENAI-API-KEY"))
os.environ["TOKENIZERS_PARALLELISM"] = "false"
os.environ['SSL_CERT_FILE'] = certifi.where()

load_dotenv()

CONNECTION_STRING = os.environ.get("PYODBC-CONNECTION")

FILE_PATH = None

def get_device():
    if torch.cuda.is_available():
        device = torch.device("cuda:0")
    elif torch.backends.mps.is_available():  # Apple M3 Silicon
        device = torch.device("mps")
    else:
        device = torch.device("cpu")
    return device

def calculate_fuzzy_scores_for_batch(
    query_batch, mapping_table_df, search_column
) -> np.ndarray:
    fuzzy_scores = np.zeros((len(mapping_table_df), len(query_batch)))
    for i, query_string in enumerate(query_batch):
        for j, row in mapping_table_df.iterrows():
            fuzzy_scores[j, i] = fuzz.ratio(query_string, row[search_column])
    return fuzzy_scores


def get_all_fuzzy_scores(
    batched_query_points: list[str],
    mapping_table_df,
    search_column="ManufacturerCatalogNumber",
    num_processes=16,
) -> np.ndarray[int]:
    # Split the query points into batches for multiprocessing

    batch_size = (
        len(batched_query_points) // num_processes
        if len(batched_query_points) // num_processes > 0
        else 1
    )

    query_batches = [
        batched_query_points[i : i + batch_size]
        for i in range(0, len(batched_query_points), batch_size)
    ]

    # Create a multiprocessing pool and distribute the work
    with multiprocessing.Pool(processes=num_processes) as pool:
        results = pool.starmap(
            calculate_fuzzy_scores_for_batch,
            [(batch, mapping_table_df, search_column) for batch in query_batches],
        )

    # Combine the results into a single matrix
    fuzzy_score_matrix = np.hstack(results).astype(int)
    return fuzzy_score_matrix


def get_all_cosine_scores(
    sentence_model: SentenceTransformer, data_points: list[str], query_points: list[str]
) -> np.ndarray[int]:
    # Encode data and query points
    data_embeddings = sentence_model.encode(
        data_points,
        convert_to_tensor=True,
        normalize_embeddings=True,
        show_progress_bar=False,
        batch_size=100,
    )
    query_embeddings = sentence_model.encode(
        query_points,
        convert_to_tensor=True,
        normalize_embeddings=True,
        show_progress_bar=False,
        batch_size=100,
    )

    # Compute cosine scores, return as int
    cosine_scores = (torch.mm(data_embeddings, query_embeddings.T) * 100).type(
        torch.int8
    )

    # Transfer cosine scores to CPU
    cosine_scores_cpu = cosine_scores.cpu().detach().numpy()

    # Clear memory
    del data_embeddings, query_embeddings, cosine_scores
    torch.cuda.empty_cache()

    return cosine_scores_cpu


def pick_best_match(
    query: pd.Series,
    matches: list[dict],
    mapping_table_df: pd.DataFrame,
    unique_cols: list[str] = ["ManufacturerId", "ManufacturerCatalogNumber"],
    update_cols: list[str] = [
        "Group",
        "Company",
        "Business",
        "Division",
        "Therapy",
        "Specialty",
        "Anatomy",
        "SubAnatomy",
        "ProductCategory",
        "ProductFamily",
    ],
    value_col: str = "Model",
    verbose: bool = False,
):
    # Example OpenAI Python library request
    MODEL = "gpt-4o-2024-05-13"
    matches_str = ""
    openai_calls: int = 0
    for i, match in enumerate(matches[:5]):
        cols_to_show = [
            col
            for col in mapping_table_df.columns
            if mapping_table_df.loc[match["index"], col]
            not in [np.nan, "Other", "None"]
        ]

        matches_str += (
            f"{i}. {dict(mapping_table_df.loc[match['index'],cols_to_show])}\n"
        )
    with open(f"{get_current_directory()}/prompt.txt", "r") as file:
        prompt = file.read()
    no_error = False
    while not no_error:
        try:
            if verbose:
                logging.info(
                    f"The query is:\n{dict(query[['ManufacturerCatalogNumber','ItemDescription']])}\n"
                )
                logging.info(f"The matches are:\n{matches_str}\n")
            response = client.chat.completions.create(
                model=MODEL,
                messages=[
                    {
                        "role": "system",
                        "content": prompt,
                    },
                    {
                        "role": "user",
                        "content": f"""This is the data : {query[['ManufacturerCatalogNumber','ItemDescription']]}. Which needs to be mapped to one of the items in this list\n{matches_str}\n""",
                    },
                ],
                temperature=0,
            )
            if verbose:
                logging.info(
                    f"GPT's response is {response.choices[0].message.content}\n"
                )
            openai_calls += 1

            return None if "None" in response.choices[0].message.content.split(" ")[
                -1
            ] else int(response.choices[0].message.content.split(" ")[-1]), openai_calls
        except ValueError as e:
            logging.exception(f"{e}")
            logging.info(
                f"GPT's response is {response.choices[0].message.content} in the except block"
            )
            sleep(1)
        except (
            openai.RateLimitError,
            openai.APITimeoutError,
            openai.APIError,
            openai.APIConnectionError,
        ) as e:
            logging.exception(f"Waiting 10 seconds...\n{e}")
            sleep(10)


def calculate_distance_matrices(
    data: pd.DataFrame,
    rows_to_map: pd.DataFrame,
    sentence_model: SentenceTransformer,
    num_processes: int = 16,
) -> tuple[np.ndarray[int], np.ndarray[int]]:
    if data.empty:
        return None, None
    fuzzy_matrix = get_all_fuzzy_scores(
        rows_to_map["ManufacturerCatalogNumber"].tolist(),
        data,
        num_processes=num_processes,
    )
    cosine_matrix = get_all_cosine_scores(
        sentence_model,
        data["ItemDescription"].tolist(),
        rows_to_map["ItemDescription"].tolist(),
    )
    return fuzzy_matrix, cosine_matrix


def find_exact_matches(
    data: pd.DataFrame,
    rows_to_map: pd.DataFrame,
    fuzzy_matrix: np.ndarray,
    unique_cols: list[str],
    update_cols: list[str],
    value_col: str,
    batch_index_shift: int,
):
    count_exact_matches = 0
    exact_matches = {}
    key_rows = ["ManufacturerId", "ManufacturerCatalogNumber", "ItemDescription"]

    if data.empty:
        return 0, exact_matches

    for index, row in rows_to_map.iterrows():
        if row["Mapped"]:
            continue
        batched_index = index - batch_index_shift
        # Get exact matches in the Fuzzy Vector

        exact_match = next(
            (
                i
                for i, value in enumerate(fuzzy_matrix[:, batched_index])
                if value == 100
            ),
            None,
        )

        if exact_match is not None:
            rows_to_map.loc[index, update_cols + [value_col]] = data.loc[
                exact_match, update_cols + [value_col]
            ]
            rows_to_map.loc[index, "Mapped"] = True
            rows_to_map.loc[index, "category_flag"] = "Exact"
            count_exact_matches += 1

            exact_matches[str(dict(row[key_rows]))] = data.loc[
                exact_match, update_cols + [value_col]
            ]
            exact_matches[str(dict(row[key_rows]))]["category_flag"] = "Exact"

    return count_exact_matches, exact_matches


def cluster_data(
    data: pd.DataFrame,
    rows_to_map: pd.DataFrame,
    cosine_matrix: np.ndarray,
    fuzzy_matrix: np.ndarray,
    unique_cols: list[str],
    update_cols: list[str],
    value_col: str,
    batch_size: int,
    batch_index_shift: int,
):
    clustered_matches = {}
    mapped_matches = {}
    clustered_key_columns = [
        "ManufacturerId",
        "ManufacturerCatalogNumber",
        "ItemDescription",
    ]
    openai_calls = 0
    openai_calls_none = 0
    total_acceptable_threshold = 120
    cluster_time = time()

    if data.empty:
        return clustered_matches, mapped_matches, openai_calls, openai_calls_none

    for index, row in rows_to_map.iterrows():
        batch_index = index - batch_index_shift
        if row["Mapped"]:
            continue

        embedding_vector = cosine_matrix[:, batch_index % batch_size].tolist()
        fuzzy_vector = fuzzy_matrix[:, batch_index % batch_size].tolist()

        if row["ItemDescription"] == "NULL":
            all_matches = [
                {
                    **data.loc[i, :],
                    "index": i,
                    "embedding": 0,
                    "fuzzy": fuzzy_vector[i],
                    "Total": 120 if fuzzy_vector[i] > 80 else fuzzy_vector[i],
                }
                for i in range(len(data))
            ]
        else:
            all_matches = [
                {
                    **data.loc[i, :],
                    "index": i,
                    "embedding": embedding_vector[i],
                    "fuzzy": fuzzy_vector[i],
                    "Total": fuzzy_vector[i] + embedding_vector[i],
                }
                for i in range(len(data))
            ]

        all_matches.sort(key=lambda x: x["Total"], reverse=True)
        matches = [
            match
            for match in all_matches
            if match["Total"] >= total_acceptable_threshold
        ]

        if matches:
            # Let OpenAi GPT choose the best one
            best_pick, calls = pick_best_match(
                row, matches, data, unique_cols=unique_cols, update_cols=update_cols
            )
            openai_calls += calls

            if best_pick is not None:
                best_match = matches[best_pick]
                best_index = best_match["index"]

                rows_to_map.loc[index, update_cols + [value_col]] = data.loc[
                    best_index, update_cols + [value_col]
                ]
                rows_to_map.loc[index, "Mapped"] = True
                rows_to_map.loc[index, "category_flag"] = "Exact-GPT"

                del best_match["index"]
                mapped_matches[str(dict(row[clustered_key_columns]))] = best_match

                continue
            else:
                openai_calls_none += 1

        cluster_key = str(dict(row[clustered_key_columns]))
        top_matches = all_matches[:5]

        if cluster_key in clustered_matches:
            clustered_matches[cluster_key].extend(top_matches)
        else:
            clustered_matches[cluster_key] = [
                match
                for match in top_matches
                if match["Total"] >= total_acceptable_threshold
            ]

        # print(f"It took {time() - row_time} seconds to finish index {index} number of matches: {len(matches)}")
    logging.info(
        f"It took {time() - cluster_time} seconds to finish clustering all rows"
    )
    return clustered_matches, mapped_matches, openai_calls, openai_calls_none

def map_data(
    inputDatasets: list[str],
    file: str | None,
    database: str,
    num_processes: int,
    all_tickers: bool,
    verbose: bool,
) -> None:
    # Open a single database connection with a 1-hour timeout
    logging.info("Connecting to SQL Server...")
    start = time()
    conn = pyodbc.connect(CONNECTION_STRING, timeout=3600)
    cursor = conn.cursor()

    unique_cols = {
        "mapping_table": [
            "ManufacturerId",
            "ManufacturerCatalogNumber",
            "ItemDescription",
        ],
        "gudid": ["ManufacturerCatalogNumber", "ItemDescription"],
    }
    update_cols = {
        "mapping_table": [
            "Group",
            "Company",
            "Business",
            "Division",
            "Therapy",
            "Specialty",
            "Anatomy",
            "SubAnatomy",
            "ProductCategory",
            "ProductFamily",
        ],
        "gudid": ["ProductCategory", "ProductFamily"],
    }
    value_col = "Model"

    logging.info("Loading unmapped data from SQL Server")
    if file is not None:
        unmapped_df = pd.read_csv(file)
    else:
        unmapped_df = get_unmapped_data(cursor)  # Get all UnMapped Rows

    # replace nan with NULL for item description
    unmapped_df["ItemDescription"] = unmapped_df["ItemDescription"].replace(
        np.nan, "NULL"
    )
    unmapped_df["Mapped"] = False
    if all_tickers:
        tickers = get_tickers(cursor)  # Get all Tickers
    else:
        tickers = pd.read_csv(f"{get_current_directory()}/tickers.csv")

    total_openai_calls = 0
    total_openai_calls_none = 0
    total_exact_matches = 0
    all_exact_matches = {ticker: {} for ticker in tickers["ticker"]}
    all_clustered_matches = {ticker: {} for ticker in tickers["ticker"]}
    all_mapped_matches = {ticker: {} for ticker in tickers["ticker"]}

    BATCH_SIZE = 5000
    logging.info(f"Total time to load unmapped data: {time() - start} seconds")
    start = time()
    device: str = get_device()
    logging.info(f"Using {device} for sentence transformer")
    sentence_model: SentenceTransformer = SentenceTransformer(
        "multi-qa-MiniLM-L6-cos-v1", device=device
    )

    logging.info(f"Tickers to map: {tickers['ticker'].unique().tolist()}")

    for _, row in tickers.iterrows():
        company_openai_calls = 0
        company_openai_calls_none = 0
        ticker = row["ticker"]
        rows_to_map = unmapped_df[unmapped_df["Ticker"] == ticker].copy()
        t_count_mapping = rows_to_map[unique_cols["mapping_table"] + ["TCount"]]
        rows_to_map.reset_index(drop=True, inplace=True)

        if rows_to_map.empty:
            logging.info(f"No rows to map for {ticker}")
            continue

        cursor = check_db_conn(CONNECTION_STRING, cursor)

        reference_data = {
            "mapping_table": get_mapping_tables(
                cursor,
                ticker,
                unique_cols["mapping_table"]
                + update_cols["mapping_table"]
                + [value_col],
            ),
            "gudid": get_gudid_data(cursor, ticker),
        }

        """This is to impute gudid with the mapping table columns    
        
        reference_data["gudid"] = reference_data["gudid"].merge(reference_data["mapping_table"].drop_duplicates(["ProductCategory","ProductFamily"]),on=["ProductCategory","ProductFamily"], how="left", indicator=True, suffixes=('', '_y'))
        # drop columns with _y
        reference_data["gudid"].drop(reference_data["gudid"].filter(regex='_y').columns, axis=1, inplace=True)
        reference_data["gudid"].drop(['_merge'], axis=1, inplace=True)"""

        for i in range(0, len(rows_to_map), BATCH_SIZE):
            batch_range = slice(i, min(i + BATCH_SIZE, len(rows_to_map)))
            batch_index = (i // BATCH_SIZE) * BATCH_SIZE
            datasets = {}

            if i == 0 and len(rows_to_map) < BATCH_SIZE:
                # If the first batch is smaller than the batch size, then we need to copy the entire dataframe
                batch_rows = rows_to_map.copy()
            else:
                batch_rows = rows_to_map[batch_range].copy()

            for dataset in inputDatasets:
                refData = reference_data[dataset]
                datasets[dataset] = {
                    "data": refData,
                    "unique_cols": unique_cols[dataset],
                    "update_cols": update_cols[dataset],
                    "matrices": calculate_distance_matrices(
                        refData,
                        batch_rows,
                        sentence_model,
                        num_processes=num_processes,
                    ),
                }

            """
            The Reason we do two loops is because of business logic. 
            We want to find exact matches first from each dataset and
            then cluster the data.
            We do not want to cluster the data if we have an exact match.
            """

            for dataset_name, dataset_info in datasets.items():
                data, unique_columns, update_columns, matrices = dataset_info.values()
                fuzzy_matrix = matrices[0]
                count_exact_matches, exact_matches = find_exact_matches(
                    data,
                    batch_rows,
                    fuzzy_matrix,
                    unique_columns,
                    update_columns,
                    value_col,
                    batch_index,
                )
                total_exact_matches += count_exact_matches
                if dataset_name == "gudid":
                    all_exact_matches[ticker].update(exact_matches)

            # Now we can cluster the data and use OpenAI
            for dataset_name, dataset_info in datasets.items():
                data, unique_columns, update_columns, matrices = dataset_info.values()
                fuzzy_matrix, cosine_matrix = matrices
                clustered_matches, mapped_matches, openai_calls, openai_calls_none = (
                    cluster_data(
                        data,
                        batch_rows,
                        cosine_matrix,
                        fuzzy_matrix,
                        unique_columns,
                        update_columns,
                        value_col,
                        BATCH_SIZE,
                        batch_index,
                    )
                )

                company_openai_calls += openai_calls
                company_openai_calls_none += openai_calls_none

                for match in clustered_matches:
                    if match in all_clustered_matches[ticker]:
                        all_clustered_matches[ticker][match].extend(
                            clustered_matches[match]
                        )
                    else:
                        all_clustered_matches[ticker][match] = clustered_matches[match]

                all_mapped_matches[ticker].update(mapped_matches)

            rows_to_map.loc[batch_rows.index] = batch_rows

        matches_found = rows_to_map["Mapped"].sum()
        # Mark rows that were mapped as true to false if any Group, Company, Business, Division, Therapy, Specialty, Anatomy, SubAnatomy is NULL
        rows_to_map["Mapped"] = rows_to_map.apply(
            lambda x: False
            if x["Mapped"]
            and x[
                [
                    "Group",
                    "Company",
                    "Business",
                    "Division",
                    "Therapy",
                    "Specialty",
                    "Anatomy",
                    "SubAnatomy",
                ]
            ]
            .isnull()
            .any()
            else x["Mapped"],
            axis=1,
        )
        rows_to_push = rows_to_map[rows_to_map["Mapped"]].copy()

        if "Manufacturer" in rows_to_push.columns:
            rows_to_push.drop(["Manufacturer", "Mapped"], axis=1, inplace=True)
        else:
            rows_to_push.drop(["Mapped"], axis=1, inplace=True)

        # Print Company Metrics, number of rows to map, number of rows mapped, number of rows not mapped, Number of openai calls, number of openai calls that returned None
        logging.info("\n")
        logging.info(f"Metrics for {ticker}")
        logging.info(f"Total unmapped rows for {ticker}: {len(rows_to_map)}")
        # logging.info(f"Total rows mapped: {matches_found}")
        logging.info(
            f"Total rows sent directly to mapping table: {len(rows_to_push)} (exact or GPT matched from Mapping table, doesn't go to UI)"
        )
        # logging.info(f"Total exact matches for {ticker}: {total_exact_matches}")
        logging.info(f"Total OpenAI calls for {ticker}: {company_openai_calls}")
        if company_openai_calls:
            logging.info(
                f"Percentage of OpenAI calls that returned None for {ticker}: {((company_openai_calls_none/company_openai_calls))*100}%"
            )
        logging.info(
            f"Number of clustered matches sent to the UI: {len(all_clustered_matches[ticker])}"
        )
        logging.info(f"Number of exact matches sent to the UI: {len(all_exact_matches[ticker])}")

        cursor = check_db_conn(CONNECTION_STRING, cursor)
        
        """
        rows_to_push means the rows that were mapped
        either Exact or Clustered that went straight
        to the Mapping Tables(ra.map_{ticker})
        
        all_clustered_matches is all matches that did
        not find an exact match will be sent to cosmosDB -clustered matches
        
        all_exact_matches is all matches that did find
        an exact match but has empty columns sent to cosmosDB -exact matches
        """
        
        if "TCount" in rows_to_push.columns:
            rows_to_push.drop(["TCount"], axis=1, inplace=True)
            
        # insert_dataframe_into_sql(rows_to_push, ticker, cursor)
        insert_matches_into_mongodb(
            all_clustered_matches[ticker],
            ticker,
            "Clustered",
            t_count_mapping,
            collection_name="input_datas",
            db_name=database,
        )
        insert_matches_into_mongodb(
            all_exact_matches[ticker],
            ticker,
            "Exact",
            t_count_mapping,
            collection_name="input_datas",
            db_name=database,
        )

        total_openai_calls += company_openai_calls
        total_openai_calls_none += company_openai_calls_none

    logging.info(f"Total time: {round((time() - start)/60, 2)} mins")

    logging.info(f"Total OpenAI calls: {total_openai_calls}")
    if total_openai_calls:
        logging.info(
            f"Percentage of OpenAI calls that returned None: {(total_openai_calls_none/total_openai_calls)*100}%"
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run mapping data script")
    parser.add_argument(
        "-d",
        "--datasets",
        nargs="+",
        help="List of strings",
        default=["mapping_table", "gudid"],
    )
    parser.add_argument(
        "-f", "--file", help="Path to the CSV file, instead of query", default=None
    )
    parser.add_argument(
        "-db", "--database", help="Database to send the data to", default="Prod"
    )
    parser.add_argument(
        "-n", "--num_processes", help="Number of processes to run", default=16, type=int
    )
    parser.add_argument(
        "-t",
        "--all_tickers",
        help="Will pull ra.Tickers, elses tickers.csv",
        action="store_false",
    )
    parser.add_argument(
        "-v", "--verbose", help="Increase output verbosity", action="store_true"
    )

    args = parser.parse_args()

    setup_logging()
    
    try:
        map_data(
            args.datasets,
            args.file,
            args.database,
            args.num_processes,
            args.all_tickers,
            args.verbose,
        )
        logging.info("Successfully Finished mapping data")

    except Exception as e:
        logging.exception(f"Error in main: {e}")
        exit(1)
