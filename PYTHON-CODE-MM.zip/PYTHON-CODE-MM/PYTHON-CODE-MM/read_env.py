from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

# Azure Key Vault setup
key_vault_name = "medminellc"
key_vault_uri = f"https://{key_vault_name}.vault.azure.net/"
credential = DefaultAzureCredential()
client = SecretClient(vault_url=key_vault_uri, credential=credential)

def fetch_secrets():
    # Fetch secrets from Azure Key Vault
    secrets = client.list_properties_of_secrets()

    # Prepare .env content
    env_content = ""
    for secret_properties in secrets:
        secret_name = secret_properties.name
        secret = client.get_secret(secret_name)
        env_content += f'{secret_name.upper()}={secret.value}' + "\n"

    return env_content

def create_env_file(env_content):
    # Create or overwrite the .env file
    with open(".env", "w") as env_file:
        env_file.write(env_content)

def main():
    env_content = fetch_secrets()
    print(env_content)
    create_env_file(env_content)
    print("Successfully created .env file with secrets from Azure Key Vault.")

if __name__ == "__main__":
    main()

# import os
# from azure.keyvault.secrets import SecretClient
# from azure.identity import DefaultAzureCredential

# keyVaultName = "KV_NAME"
# KVUri = f"https://KV_NAME.vault.azure.net"

# credential = DefaultAzureCredential()
# client = SecretClient(vault_url=KVUri, credential=credential)

# secretName = "SECRET_NAME"
# secretValue = "SECRET_VALUE"

# print(f"Creating a secret in KV_NAME called '{secretName}' with the value '{secretValue}' ...")

# client.set_secret(secretName, secretValue)

# print(" done.")

# print(f"Retrieving your secret from KV_NAME.")

# retrieved_secret = client.get_secret(secretName)

# print(f"Your secret is '{retrieved_secret.value}'.")
# print(f"Deleting your secret from KV_NAME ...")

# poller = client.begin_delete_secret(secretName)
# deleted_secret = poller.result()

# print(" done.")

