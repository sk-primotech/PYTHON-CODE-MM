# Import FastAPI

from dotenv import load_dotenv
from cosmos_db_interface import MongoDBInterface
from os import getenv
from pyodbc import connect, Error
from utils import insert_dataframe_into_sql


# Load the environment variables
load_dotenv()
CONNECTION_STRING = getenv("PYODBC-CONNECTION")

# Create a connection to the SQL database
try:
    SQL_CONNECTION = connect(CONNECTION_STRING, timeout=3600)
    print("Connected to the database")
except Error as pydocError:
    print(f"Error connecting to the database: {pydocError}")
    exit()


async def all_tickers():
    try:
        cursor = SQL_CONNECTION.cursor()
        MONGO_INTERFACE = MongoDBInterface()

        df = MONGO_INTERFACE.get_all_documents_as_dataframe(
            "approveclusters",
            filter={"$or": [{"published": False}, {"published": {"$exists": False}}]},
            projection={
                "_id": 1,
                "ManufacturerId": 1,
                "ticker": 1,
                "ManufacturerCatalogNumber": 1,
                "ItemDescription": 1,
                "Company": 1,
                "Group": 1,
                "Business": 1,
                "Division": 1,
                "Therapy": 1,
                "Specialty": 1,
                "Anatomy": 1,
                "SubAnatomy": 1,
                "ProductCategory": 1,
                "ProductFamily": 1,
                "Model": 1,
                "SubDivision": 1,
                "Size": 1,
            },
        )

        result = []
        if not df.empty:
            for ticker in list(df["ticker"].unique()):
                ticker_df = df[df["ticker"] == ticker]
                remove_ids_df = ticker_df.drop(columns=["_id"])
                ids = list(ticker_df["_id"])

                insert_dataframe_into_sql(remove_ids_df, ticker, cursor)
                MONGO_INTERFACE.update_many_documents(
                    "approveclusters",
                    {"_id": {"$in": ids}},
                    {"$set": {"published": True}},
                )

                result.append(
                    {
                        "ticker": ticker,
                        "nRows": len(ticker_df.index),
                    }
                )
    finally:
        cursor.close()
        pass

    return {
        "message": f"Successfully updated {len(result)} tickers",
        "result": result,
        "nTickers": len(result),
    }


if __name__ == "__main__":
    import asyncio

    print(asyncio.run(all_tickers()))
