
import os

import certifi
import pandas as pd
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv()

os.environ['SSL_CERT_FILE'] = certifi.where()

class MongoDBInterface:
    "Interface for interacting with MongoDB"

    def __init__(self, connection_string = os.getenv("MONGO-CONNECTION-STRING") , database_name = os.getenv("MONGO-DATABASE-NAME") ):
        self.client = MongoClient(connection_string)
        self.db = self.client[database_name]

    def get_collection(self, collection_name):
        return self.db[collection_name]
    
    def create_collection(self, collection_name):
        return self.db.create_collection(collection_name)
    
    def list_collections(self):
        return self.db.list_collection_names()

    def delete_document(self, collection_name, query):
        return self.db[collection_name].delete_one(query)

    def delete_documents(self, collection_name, query):
        return self.db[collection_name].delete_many(query)

    def get_document(self, collection_name, query):
        return self.db[collection_name].find_one(query)
    
    def get_documents(self, collection_name, query):
        return self.db[collection_name].find(query)
    
    def get_documents_by_ticker(self, collection_name, ticker):
        return self.db[collection_name].find({"ticker": ticker})
    
    def get_all_documents(self, collection_name):
        return self.db[collection_name].find()
    
    def insert_document(self, collection_name, document):
        return self.db[collection_name].insert_one(document)

    def insert_documents(self, collection_name, documents):
        return self.db[collection_name].insert_many(documents)

    def upsert_document(self, collection_name, query, document):
        return self.db[collection_name].update_one(query, document, upsert=True)

    def update_many_documents(self, collection_name, query, document):
        return self.db[collection_name].update_many(query, document)

    def get_all_documents_as_dataframe(self, collection_name, filter={}, projection={}):
        cursor = self.db[collection_name].find(filter=filter, projection=projection)
        df = pd.DataFrame(list(cursor))
        return df
    
if __name__ == "__main__":
    # Usage
    connection_string = os.getenv("MONGO-CONNECTION-STRING")
    database_name = 'Prod' #os.getenv("MONGO-DATABASE-NAME")
    mongo_interface = MongoDBInterface(connection_string, database_name)
