import ast
import json
import logging
import os
from datetime import datetime

import numpy as np
import pandas as pd
import pyodbc
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
from cosmos_db_interface import MongoDBInterface


def get_current_directory() -> str:
    return os.path.dirname(os.path.realpath(__file__))

def get_unmapped_data(cursor: pyodbc.Cursor) -> pd.DataFrame:
    with open(f"{get_current_directory()}/pull_down_query.txt", "r") as f:
        query = f.read()
    cursor.execute(query)
    unmapped_data_df = pd.DataFrame.from_records(
        cursor.fetchall(), columns=[col[0] for col in cursor.description]
    )
    return unmapped_data_df


def get_tickers(cursor: pyodbc.Cursor) -> pd.DataFrame:
    cursor.execute("SELECT * FROM ra.Tickers")

    tickers = pd.DataFrame.from_records(
        cursor.fetchall(), columns=[col[0] for col in cursor.description]
    )
    return tickers


def get_mapping_tables(
    cursor: pyodbc.Cursor, ticker: str, columns_needed: list[str]
) -> pd.DataFrame:
    cursor.execute(f"SELECT * FROM ra.map_{ticker} WHERE [ProductCategory] != 'Other'")
    mapping_table_df = pd.DataFrame.from_records(
        cursor.fetchall(), columns=[col[0] for col in cursor.description]
    )
    mapping_table_df = mapping_table_df[columns_needed]
    mapping_table_df.reset_index(drop=True, inplace=True)
    # mapping_table_df["source"] = "mapping"
    return mapping_table_df


def get_gudid_data(cursor: pyodbc.Cursor, ticker: str) -> pd.DataFrame:
    m_a_companies = pd.DataFrame.from_records(
        cursor.execute(
            f"SELECT * FROM mm.gudid_search WHERE [Ticker] = '{ticker}'"
        ).fetchall(),
        columns=[col[0] for col in cursor.description],
    )
    if m_a_companies.empty:
        return pd.DataFrame()
    companies_list = (
        m_a_companies["GUDID company Name"].map(lambda x: f"'{x}'").tolist()
    )

    # Join the list into a string with commas
    companies_str = ", ".join(companies_list)

    # Use the string in the SQL query
    cursor.execute(f"SELECT * FROM mm.gudid WHERE companyName IN ({companies_str})")

    gudid = pd.DataFrame.from_records(
        cursor.fetchall(), columns=[col[0] for col in cursor.description]
    )

    gudid["catalogNumber"].fillna(gudid["versionModelNumber"])
    gudid.dropna(subset=["companyName", "deviceDescription"], inplace=True)
    gudid.drop_duplicates(inplace=True)
    gudid["deviceDescription"].fillna("-")
    gudid["catalogNumber"] = gudid["catalogNumber"].fillna(gudid["versionModelNumber"])
    gudid.rename(
        columns={
            "catalogNumber": "ManufacturerCatalogNumber",
            "deviceDescription": "ItemDescription",
            "gmdnPTName": "ProductCategory",
            "brandName": "ProductFamily",
            "companyName": "Company",
        },
        inplace=True,
    )
    gudid["Model"] = gudid["ManufacturerCatalogNumber"]
    # drop '-' and '.' from catalog numbers
    gudid["ManufacturerCatalogNumber"] = gudid["ManufacturerCatalogNumber"].str.replace(
        "-", ""
    )
    gudid["ManufacturerCatalogNumber"] = gudid["ManufacturerCatalogNumber"].str.replace(
        ".", ""
    )
    gudid.reset_index(drop=True, inplace=True)
    gudid.drop(
        [
            "publicDeviceRecordKey",
            "PrimaryDI",
            "deviceIdIssuingAgency",
            "versionModelNumber",
            "deviceId",
        ],
        inplace=True,
        axis=1,
    )
    # drop all tm symbol and registered symbol from ProductFamily and ProductCategory
    gudid["ProductFamily"] = gudid["ProductFamily"].str.replace("™", "")
    gudid["ProductFamily"] = gudid["ProductFamily"].str.replace("®", "")
    gudid["ProductCategory"] = gudid["ProductCategory"].str.replace("™", "")
    gudid["ProductCategory"] = gudid["ProductCategory"].str.replace("®", "")

    return gudid


def insert_dataframe_into_sql(
    insert_df: pd.DataFrame, ticker: str, cursor: pyodbc.Cursor
):
    if insert_df.empty:
        return

    for index, row in insert_df.iterrows():
        values = []
        for value in row:
            if value in [None, "None", "nan"] or pd.isna(value):
                continue
            elif isinstance(value, str):
                value = value.replace("'", "''") if isinstance(value, str) else value
                values.append(f"'{value}'")
            else:
                values.append(str(value))
        values = ",".join(values)
        columns = ", ".join(
            [
                f"[{col}]"
                for col in insert_df.columns
                if row[col] not in [None, "None", "nan"] and pd.isna(row[col]) == False  # noqa: E712
            ]
        )  # noqa: E712
        sql_insert_query = (
            f"INSERT INTO ra.map_{ticker} ({columns}) VALUES ({values})".replace(
                "None", "NULL"
            )
        )  # PRODUCTION
        try:
            cursor.execute(sql_insert_query)
            cursor.commit()
        except Exception as e:
            logging.error(f"THIS QUERY FAILED: \n{sql_insert_query}")
            logging.error(f"With Error:\n{e}\n")
            raise e


def convert_numpy_to_python(value):
    """
    Recursively convert numpy data types in a structure to their Python counterparts.
    Handles dictionaries, lists, numpy scalars, and numpy arrays.
    """
    if isinstance(value, np.generic):
        return value.item()
    elif isinstance(value, np.ndarray):
        return value.tolist()
    elif isinstance(value, dict):
        return {k: convert_numpy_to_python(v) for k, v in value.items()}
    elif isinstance(value, list):
        return [convert_numpy_to_python(v) for v in value]
    else:
        return value


def insert_matches_into_mongodb(
    matches: dict,
    ticker: str,
    category: str,
    t_counts: pd.DataFrame,
    collection_name: str = "test_input_datas",
    db_name: str = "Prod",
) -> None:
    if not matches:
        return

    mongo_interface = MongoDBInterface(database_name=db_name)
    documents = []
    today = datetime.now().strftime("%Y-%m-%d")
    for key in matches:
        key_dict = ast.literal_eval(key)
        match_data = convert_numpy_to_python(matches[key])
        # where ManufacturerId, ManufacturerCatalogNumber, ItemDescription are the same as the key_dict
        t_count = t_counts[
            (t_counts["ManufacturerId"] == key_dict["ManufacturerId"])
            & (
                t_counts["ManufacturerCatalogNumber"]
                == key_dict["ManufacturerCatalogNumber"]
            )
            & (t_counts["ItemDescription"] == key_dict["ItemDescription"])
        ]["TCount"].values[0]

        if category == "Clustered":
            documents.append(
                {
                    **key_dict,
                    "TCount": int(t_count),
                    "ticker": ticker,
                    "category_flag": "Clustered",
                    "created_date": today,
                    "Clustered_point": match_data,
                }
            )
        elif category == "Exact":
            match_data = dict(match_data)
            documents.append(
                {
                    **key_dict,
                    "TCount": int(t_count),
                    "ticker": ticker,
                    "category_flag": "Exact",
                    "created_date": today,
                    "Exact_point": match_data,
                }
            )
        else:
            print(f"Category {category} not recognized")
    mongo_interface.insert_documents(collection_name, documents)


def handle_non_serializable(obj):
    if isinstance(obj, np.int64):
        return int(obj)
    elif isinstance(obj, np.float64):
        return int(obj)

    elif isinstance(obj, np.ndarray):
        print(obj)
        return obj.tolist()


def azure_blob_upload(
    account_url: str,
    container_name: str = "input-container",
    folder_path: str = "Mapping_data/companies",
) -> None:
    try:
        azure_blob_clear_containers(account_url)

        # Get a credential using the DefaultAzureCredential
        credential = DefaultAzureCredential()
        print(credential._successful_credential)
        blob_service_client = BlobServiceClient(
            account_url=account_url, credential=credential
        )

        # Get the container client
        container_client = blob_service_client.get_container_client(container_name)

        # loop through files in folder
        for file in os.listdir(folder_path):
            source_file_path = os.path.join(folder_path, file)
            blob_name = os.path.basename(source_file_path)

            blob_client = container_client.get_blob_client(blob_name)

            # Upload the file
            with open(source_file_path, "rb") as data:
                blob_client.upload_blob(data, overwrite=True)
            print(
                f"File {source_file_path} uploaded to blob storage as blob {blob_name}"
            )

    except Exception as e:
        print(f"An exception occurred: {e}")


def azure_blob_clear_containers(
    account_url: str,
    source_container_name: str = "input-container",
    in_progress_container_name: str = "in-progress-container",
) -> None:
    try:
        # Setup the BlobServiceClient with Azure credentials
        credential = DefaultAzureCredential()
        blob_service_client = BlobServiceClient(
            account_url=account_url, credential=credential
        )

        # Check if source container is empty
        source_container_client = blob_service_client.get_container_client(
            source_container_name
        )
        blobs_in_source = list(source_container_client.list_blobs())
        if not blobs_in_source:
            print("Source container is empty. No action taken.")
            return

        # Remove blobs from the source container
        for blob in blobs_in_source:
            source_container_client.delete_blob(blob.name)

        # Remove blobs from the 'in-progress' container
        in_progress_container_client = blob_service_client.get_container_client(
            in_progress_container_name
        )
        for blob in in_progress_container_client.list_blobs():
            in_progress_container_client.delete_blob(blob.name)

        print("Blobs removed from both containers.")

    except Exception as e:
        print(f"An exception occurred: {e}")


def check_db_conn(connection_string: str, cursor: pyodbc.Cursor):
    try:
        cursor.execute("SELECT 1")
        cursor.commit()
        return cursor
    except Exception:
        logging.exception("Connection timed out, reconnecting...")
        conn = pyodbc.connect(connection_string, timeout=3600)
        cursor = conn.cursor()
        return cursor


def setup_logging(file_name: str = datetime.now().strftime("%Y-%m-%d_%H-%M")):
    file_name = 'C:\\Users\\ML_admin\\src\MedMineLLC\\logging\\' + file_name
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)  # Capture all levels of logs

    # Remove any existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    loggingFolder = get_current_directory() + "/logging"

    if not os.path.exists(loggingFolder):
        os.makedirs(loggingFolder)
    else:
        for file in os.listdir(loggingFolder):
            os.remove(f"{loggingFolder}/{file}")

    # Add the file handler
    file_path = os.path.join(loggingFolder, f"{file_name}.log")
    file_handler = logging.FileHandler(file_path)
    formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return file_path


if __name__ == "__main__":
    # This is a utility file, it should not be run directly, unless you are testing a function
    # read Mapping_data/companies/AORT.json into list of dicts
    with open("Mapping_data/companies/ABT.json", "r") as f:
        data = json.load(f)
    # pretty print the data

    insert_matches_into_mongodb(data, "ABT", "Clustered", "input_datas")

    with open("Mapping_data/companies_mapped/AMBUB_mapped_matches.json", "r") as f:
        data = json.load(f)

    insert_matches_into_mongodb(data, "AMBUB", "Exact", "input_datas")
