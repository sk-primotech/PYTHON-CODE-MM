import paramiko
import os
from dotenv import load_dotenv

# Load environment variables from the .env file
load_dotenv()


def run_command_as_root(ip_address, username, password, command):
    # Initialize SSH client
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        # Connect to the server using username and password
        ssh.connect(ip_address, username=username, password=password)

        # Command to run as root. Adjust the command as needed.
        # Using 'sudo sh -c' allows for more complex commands and operations.
        sudo_command = f"sudo sh -c '{command}'"

        # Execute the sudo command
        stdin, stdout, stderr = ssh.exec_command(sudo_command)

        # Read command output and errors
        output = stdout.read().decode("utf-8")
        error = stderr.read().decode("utf-8")

        if output:
            print("Output:")
            print(output)
        if error:
            print("Error:")
            print(error)

    finally:
        # Close the SSH connection
        ssh.close()


# Example Variables for SSH connection and command execution
ip_address = os.getenv("UI-SERVER-IP-ADDRESS")
username = os.getenv("UI-SERVER-USERNAME")
password = os.getenv("UI-SERVER-PASSWORD")

# Example command to run as root
command_to_run_as_root = ""

# Run the script with the specified variables
run_command_as_root(ip_address, username, password, command_to_run_as_root)
