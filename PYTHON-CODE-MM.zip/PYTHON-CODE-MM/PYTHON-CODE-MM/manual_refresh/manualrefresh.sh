#!/bin/sh
cd /var/www/Datahelper-Backend/src
sudo su
rm -rf clusteredFiles updatedFiles Approval
cd /var/www/Datahelper-Backend
forever stop server.js
forever start server.js
