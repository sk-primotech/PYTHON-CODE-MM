from fastapi import HTTPException, status, FastAPI, BackgroundTasks, Depends
from pydantic import BaseModel
from path import Path
import sys
from fastapi.responses import RedirectResponse
from auth import get_user

# directory reach
directory = Path(__file__).absolute()

# setting path
sys.path.append(directory.parent.parent)

from excel_refresh import ExcelRefresher  # noqa: E402 # This needs to be after sys.path.append to import the excel_refresh module

app = FastAPI(
    dependencies=[Depends(get_user)],
)

CURRENT_TASK = None  # Current class of task
CURRENT_TASK_RUNNING: bool = False  # Current status of task

class RequestBody(BaseModel):
    directory: str = None
    no_new_combinations: bool = False
    new_combinations: bool = False
    tickers: list = []


def verify_directory(body: RequestBody):
    if not body.directory:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing parameter in request body",
        )


# The below function is used to run the task in the background as well as to
# reset the CURRENT_TASK to None after the task is completed
def run_task():
    global CURRENT_TASK
    global CURRENT_TASK_RUNNING
    CURRENT_TASK.run_excel_refresh()
    CURRENT_TASK_RUNNING = False

@app.post("/refresh/{method}")
async def refresh_root(
    method: str, body: RequestBody, background_tasks: BackgroundTasks
):
    verify_directory(body)

    global CURRENT_TASK_RUNNING

    if CURRENT_TASK_RUNNING:
        return RedirectResponse(
            "/refresh/status", status_code=status.HTTP_303_SEE_OTHER
        )

    global CURRENT_TASK
    no_new_combinations = False
    new_combinations = False
    tickers = []

    if method == "new_combinations":
        new_combinations = True
    elif method == "no_new_combinations":
        no_new_combinations = True
    elif method == "tickers":
        tickers = body.tickers
        if not tickers:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Missing parameter in request body",
            )
    else:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
        )

    CURRENT_TASK = ExcelRefresher(
        body.directory, no_new_combinations, new_combinations, tickers
    )
    CURRENT_TASK_RUNNING = True

    background_tasks.add_task(run_task)

    return RedirectResponse("/refresh/status", status_code=status.HTTP_303_SEE_OTHER)


@app.get("/refresh/status")
async def refresh_status():
    global CURRENT_TASK_RUNNING
    global CURRENT_TASK

    if CURRENT_TASK is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No task is currently running. Please start a task first.",
        )
    elif CURRENT_TASK_RUNNING:
        return CURRENT_TASK.progress_data
    elif not CURRENT_TASK_RUNNING and CURRENT_TASK is not None:
        return {
            "NOTE" : "Task has been completed. Please start a new task to refresh the excel file.",
            "oldResult" : CURRENT_TASK.progress_data
        }
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No task is currently running. Please start a task first.",
        )

@app.get("/health")
async def health():
    return {"message": "Healthy"}
