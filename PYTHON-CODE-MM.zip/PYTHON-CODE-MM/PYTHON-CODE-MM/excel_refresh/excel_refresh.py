import logging
from os import environ, listdir, path, system, mkdir
import pyodbc
from dotenv import load_dotenv

import argparse
import datetime
import pandas as pd
import threading
import win32com.client

load_dotenv()


class ExcelRefresher:
    def __init__(
        self,
        filepath: str,
        run_no_new_combinations: bool,
        run_new_combinations: bool,
        manual_tickers: list[str],
    ):
        self.filepath = filepath
        self.run_no_new_combinations = run_no_new_combinations
        self.run_new_combinations = run_new_combinations
        self.manual_tickers = manual_tickers
        self.conn = None
        self.cursor = None
        self._connect_to_database()
        self.file_list = [
            file for file in listdir(self.filepath) if "MedMiner_Model" in file
        ]
        self.previous_thursday = self._get_previous_thursday()
        self.current_date = datetime.datetime.now()
        self.refreshed_models_folder = path.join(
            self.filepath, f"refreshed_models_{self.current_date.strftime('%Y-%m-%d')}"
        )
        self.backupFolder = path.join(
            self.filepath, f"backup_{self.previous_thursday.strftime('%Y-%m-%d')}"
        )

        if path.exists(self.backupFolder):
            self.backup_file_list = [
                file
                for file in listdir(self.backupFolder)
                if "MedMiner_Model" in file
            ]
        else:
            self.backup_file_list = []

        self.progress_data = {
            "status": "Preparing folders and creating backups. This may take a few minutes.",
        }

    def _connect_to_database(self):
        try:
            connection_string = environ.get("PYODBC-CONNECTION")
            self.conn = pyodbc.connect(connection_string, timeout=3600)
            self.cursor = self.conn.cursor()
        except Exception as e:
            logging.error(f"Error connecting to database: {e}")
            raise

    def _get_previous_thursday(self):
        today = datetime.date.today()
        weekday_num = today.weekday()
        if weekday_num == 3:  # If today is Thursday
            days_to_subtract = 7
        elif weekday_num < 3:  # If today is before Thursday
            days_to_subtract = weekday_num + 4 + 7
        else:  # If today is after Thursday
            days_to_subtract = weekday_num - 3 + 7

        previous_thursday = today - datetime.timedelta(days=days_to_subtract)
        return previous_thursday

    def _get_unmapped_data(self) -> pd.DataFrame:
        script_dir = path.dirname(
            path.abspath(__file__)
        )  # Get the directory of the script
        query_file_path = path.join(
            script_dir, "../Mapping_data/pull_down_query.txt"
        )  # Construct the relative path

        with open(query_file_path, "r") as f:
            query = f.read()

        self.cursor.execute(query)
        unmapped_data_df = pd.DataFrame.from_records(
            self.cursor.fetchall(), columns=[col[0] for col in self.cursor.description]
        )
        return unmapped_data_df

    def _setup_directories(self):
        # Copy all files to a backup directory
        if not path.exists(self.backupFolder):
            mkdir(self.backupFolder)

        # Create a directory to save the refreshed models
        if not path.exists(self.refreshed_models_folder):
            mkdir(self.refreshed_models_folder)

    def _setup_logging(self, directory: str, logName: str, level=logging.INFO):
        """To setup as many loggers as you want"""
        logFilePath = path.join(directory, logName)

        handler = logging.FileHandler(logFilePath)
        handler.setFormatter(
            logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        )

        logger = logging.getLogger(logName)
        logger.setLevel(level)
        logger.addHandler(handler)

        # Add a console handler
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(
            logging.Formatter("%(asctime)s - %(levelname)s - %(message)s")
        )
        logger.addHandler(console_handler)

        return logger

    def _close_logging(self, logger: logging.Logger):
        for handler in logger.handlers:
            handler.close()
            logger.removeHandler(handler)


    def _get_files_and_logging(self, tickers: list[str], logName: str):
        logger = self._setup_logging(self.refreshed_models_folder, logName)

        # list all files in the directory that contain 'MedMiner_Model' in the name and container a ticker from tickers
        excel_files = [
            file
            for file in self.backup_file_list
            if any(tick in file for tick in tickers)
        ]

        newFiles = list()
        todo_tickers = list()
        for file in excel_files:
            ticker = file.split("-")[1].split("-")[0].strip()
            newFiles.append(
                {
                    "path": path.join(self.backupFolder, file),
                    "saveAs": path.join(self.refreshed_models_folder, file),
                    "file": file,
                    "ticker": ticker,
                }
            )
            todo_tickers.append(ticker)

        return newFiles, logger, todo_tickers

    def _refresh_files(self, newFiles: list[dict[str, str]], logger: logging.Logger):
        # Create a lock for thread-safe logging
        log_lock = threading.Lock()

        # Create a semaphore to limit the number of concurrent threads
        semaphore = threading.Semaphore(2)  # Limit to 2 concurrent threads

        # Define a function to refresh a single file
        def refresh_file(file_info):
            with semaphore:  # Acquire the semaphore
                exlapp = win32com.client.DispatchEx("Excel.Application")
                exlapp.DisplayAlerts = False
                
                with log_lock:
                    logger.info(
                        f"[{file_info['ticker']}] - Starting refresh for {file_info['ticker']}. Logs may be scattered."
                    )
                    self.progress_data["tickers"]["todo"].remove(file_info["ticker"])
                    self.progress_data["tickers"]["in_progress"].append(
                        file_info["ticker"]
                    )

                try:
                    with log_lock:
                        logger.info(
                            f"[{file_info['ticker']}] - Opening {file_info['file']}..."
                        )
                    wkbk = exlapp.Workbooks.Open(file_info["path"])

                    with log_lock:
                        logger.info(
                            f"[{file_info['ticker']}] - Refreshing all connections for {file_info['file']}..."
                        )

                    wkbk.RefreshAll()
                    exlapp.CalculateUntilAsyncQueriesDone()

                    saveTo = path.join(file_info["saveAs"])
                    with log_lock:
                        logger.info(
                            f"[{file_info['ticker']}] - Successfully completed refresh for {file_info['file']}. Saving to {saveTo}..."
                        )
                        wkbk.SaveAs(saveTo, FileFormat=51)

                    wkbk.Close(SaveChanges=False)
                    with log_lock:
                        logger.info(
                            f"[{file_info['ticker']}] - Closed {file_info['file']}"
                        )

                except Exception as e:
                    with log_lock:
                        self.errorLogger.error(f"[{file_info['ticker']}] - {e}")
                        self.progress_data["tickers"]["error"].append(
                            file_info["ticker"]
                        )
                finally:
                    with log_lock:
                        self.progress_data["tickers"]["in_progress"].remove(
                            file_info["ticker"]
                        )
                        self.progress_data["tickers"]["done"].append(
                            file_info["ticker"]
                        )

                        self.progress_data["percent_complete"] = round(
                            (
                                len(self.progress_data["tickers"]["done"])
                                / self.total_tickers_length
                            )
                            * 100,
                            2,
                        )

                exlapp.Quit()

        # Create a list of threads
        threads = []

        # Iterate over new files and create a thread for each file
        for file_info in newFiles:
            thread = threading.Thread(target=refresh_file, args=(file_info,))
            threads.append(thread)
            thread.start()

        # Wait for all threads to complete
        for thread in threads:
            thread.join()

        logger.info("Excel Refresh Complete")

    def run_excel_refresh(self):
        if (
            not self.run_no_new_combinations
            and not self.run_new_combinations
            and not self.manual_tickers
        ):
            logging.error("Please specify which files to run.")
            return

        if (
            self.run_no_new_combinations or self.run_new_combinations
        ) and self.manual_tickers:
            logging.error("Please specify either tickers or no_new_data/new_data.")
            return

        if not path.isdir(self.filepath):
            logging.error("Invalid directory.")
            return

        self._setup_directories()

        for file in self.file_list:
            toPath = path.join(self.backupFolder, file)
            if not path.exists(toPath):
                system(f"cp --preserve=timestamps '{self.filepath}/{file}' '{toPath}'")
                self.backup_file_list.append(file)

        if not self.backup_file_list:
            logging.error("No files found.")
            return

        tickers = [
            tick[0]
            for tick in self.cursor.execute("SELECT Ticker FROM ra.Tickers").fetchall()
        ]

        unmapped_data = self._get_unmapped_data()
        unmapped_dict = dict(unmapped_data["Ticker"].value_counts())

        self.errorLogger = self._setup_logging(
            self.refreshed_models_folder, "error.log"
        )

        self.progress_data = {
            "start_time": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "status": "In Progress",
            "percent_complete": 0,
            "tickers": {
                "todo": [],
                "in_progress": [],
                "done": [],
                "error": [],
            },
        }

        manualLogger: logging = None
        noNewCombLogger: logging = None
        newCombLogger: logging = None

        manualFiles: list[dict] = None
        noNewCombFiles: list[dict] = None
        newCombFiles: list[dict] = None

        if self.manual_tickers:
            manualFiles, manualLogger, todo_tickers = self._get_files_and_logging(
                self.manual_tickers,
                "manual_tickers.log",
            )
            self.progress_data["tickers"]["todo"] += todo_tickers

        if self.run_no_new_combinations:
            no_combinations_tickers = [
                tick for tick in tickers if tick not in unmapped_dict
            ] + ["OMI", "Corevalve"]
            noNewCombFiles, noNewCombLogger, todo_tickers = self._get_files_and_logging(
                no_combinations_tickers,
                "no_new_combinations.log",
            )
            self.progress_data["tickers"]["todo"] += todo_tickers

        if self.run_new_combinations:
            new_combinations_tickers = [
                tick for tick in tickers if tick in unmapped_dict
            ]
            newCombFiles, newCombLogger, todo_tickers = self._get_files_and_logging(
                new_combinations_tickers,
                "new_combinations.log",
            )
            self.progress_data["tickers"]["todo"] += todo_tickers

        self.total_tickers_length = len(self.progress_data["tickers"]["todo"])

        # The seperation of the following if statements is to ensure that we run the tickers in the order of manual, no_new_combinations, and new_combinations (if applicable)
        # The above if statements are added above to allow for the progress_data to be updated with the tickers that are to be run

        if self.manual_tickers:
            manualLogger.info(f"Tickers to be refreshed: {self.manual_tickers}")
            self._refresh_files(manualFiles, manualLogger)
            self._close_logging(manualLogger)

        if self.run_no_new_combinations:
            noNewCombLogger.info(f"Tickers to be refreshed: {no_combinations_tickers}")
            self._refresh_files(noNewCombFiles, noNewCombLogger)
            self._close_logging(noNewCombLogger)

        if self.run_new_combinations:
            newCombLogger.info(f"Tickers to be refreshed: {new_combinations_tickers}")
            self._refresh_files(newCombFiles, newCombLogger)
            self._close_logging(newCombLogger)

        self._close_logging(self.errorLogger)

        self.progress_data["status"] = "Complete"
        self.progress_data["end_time"] = datetime.datetime.now().strftime(
            "%Y-%m-%d %H:%M:%S"
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--directory",
        help="The directory where the files are located",
        required=True,
    )
    parser.add_argument(
        "--no_new_combinations",
        help="Run the no new combinations files",
        action="store_true",
    )
    parser.add_argument(
        "--new_combinations",
        help="Run the new combinations files",
        action="store_true",
    )
    parser.add_argument(
        "--tickers",
        help="List of tickers to run",
        nargs="+",
    )

    args = parser.parse_args()

    refresher = ExcelRefresher(
        args.directory,
        args.no_new_combinations,
        args.new_combinations,
        args.tickers,
    )
    refresher.run_excel_refresh()
