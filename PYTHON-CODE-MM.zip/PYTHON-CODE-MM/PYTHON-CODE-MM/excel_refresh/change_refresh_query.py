import win32com.client as win32
import os

def update_refresh_query(folder_path):
    # Open Excel
    excel = win32.gencache.EnsureDispatch('Excel.Application')

    # Iterate through each file in the folder
    for filename in os.listdir(folder_path):
        if filename.endswith('.xlsx'):  # Check if the file is an Excel workbook
            parts = filename.split(' - ')
           
            ticker = parts[1] if len(parts) >= 3 else ''
            new_query = f"""
                SELECT 
                    CAST(CAST([YEAR] AS varchar) + '-' + CAST([Month] AS varchar) + '-' + CAST('1' AS varchar) AS DATE) as 'Date',
                    FacilityID,FacilityType,
                    Case when isnumeric(BedSize) = 1 then CASE WHEN BedSize =0 THEN '1)0-0' WHEN BedSize BETWEEN 1 AND 50 THEN '2)1-50' WHEN BedSize BETWEEN 51 AND 100 THEN '3)51-100' WHEN BedSize BETWEEN 101 AND 200 THEN '4)101-200' WHEN BedSize BETWEEN 201 AND 400 THEN '5)201-400' WHEN BedSize BETWEEN 401 AND 600 THEN '6)401-600' WHEN BedSize BETWEEN 601 AND 1000 THEN '7)601-1000' WHEN BedSize BETWEEN 1001 and 2000 THEN '8)1001-2000' WHEN BedSize BETWEEN 2001 and 10000 THEN '9)2001-10000' END When isnumeric(BedSize) = 0 then Case when BedSize like '0-0' THEN '1)0-0' WHEN BedSize like '1-50'  THEN '2)1-50' WHEN BedSize like '51-100'  THEN '3)51-100' WHEN BedSize like '101-200' THEN '4)101-200' WHEN BedSize like '201-400' THEN '5)201-400' WHEN BedSize like '401-600' THEN '6)401-600' WHEN BedSize like '601-1000' THEN '7)601-1000' WHEN BedSize like '1001-2000' THEN '8)1001-2000' WHEN BedSize like '2001-10000' THEN '9)2001-10000' else BedSize end else BedSize end as 'BedSize',
                    Region ,
                    Ticker,
                    case when Company IS NULL then 'Intuitive Surgical, Inc' when Company = '' then 'Intuitive Surgical, Inc' else Company end as Manufacturer,
                    [Group],
                    Business,
                    [Division],
                    Therapy,
                    [Specialty],
                    [Anatomy],
                    [SubAnatomy],
                    ProductCategory,
                    ProductFamily,
                    Model,
                    Quantity,
                    PricePaid,
                    TotalSpend,
                    ManufacturerID,
                    ManufacturercatalogNum,
                    ItemDesc
                FROM ecri.priceguide_mapped WHERE ticker = '{ticker}'
                """
            file_path = os.path.join(folder_path, filename)
            print(f"Updating {file_path}")
            
            # Open the workbook
            wb = excel.Workbooks.Open(file_path)

            # Access the workbook's connection and update the query
            connection = wb.Connections.Item(1)  # Assuming you want to change the first connection
            connection.OLEDBConnection.CommandText = new_query

            # Save and close the workbook
            wb.Save()
            wb.Close()

    # Quit Excel
    excel.Quit()
    
if __name__ == "__main__":

    # Example usage
    folder_path = 'C:\\Users\\ML_admin\\Downloads\\Working Models - new query'

    update_refresh_query(folder_path)
