# This powershell script is used on the Azure Automation account (automatic-mapping-automation)
# to start the VM, run the python script, and stop the VM.
# The script will finish when the python script finishes running.

param
(
    [Parameter (Mandatory = $false)]
    [object] $WebhookData
)

# Variables
$resourceGroupName = 'automatic-mapping-cluster_group'
$vmName = 'automatic-mapping-cluster'

# Define the command to run on the VM
$scriptPath = "c:\Users\ML_admin\src\MedMineLLC"
$pythonExecutable = "c:/Users/ML_admin/src/MedMineLLC/medmine-env/Scripts/python.exe"
$pythonScript = "Mapping_data\map_data.py"
$pythonCommand = "cd $scriptPath; & $pythonExecutable $pythonScript"

Connect-AzAccount -Identity

# Start the VM
Start-AzVM -Name $vmName -ResourceGroupName $resourceGroupName

# Run the command on the VM
Set-AzVMRunCommand -ResourceGroupName $resourceGroupName -VMName $vmName -Location 'North Central US' -RunCommandName "RunPowerShellScript" -SourceScript $pythonCommand

$response = @{
    status  = "Succeeded"
    message = "Runbook completed successfully."
    script  = $pythonCommand
}

Write-Output (ConvertTo-Json $response)


if ($WebhookData) {
    Write-Output (ConvertTo-Json $WebhookData)
    $parameters = (ConvertFrom-Json -InputObject $WebhookData.RequestBody)
    if ($parameters.callBackUri) {
        $callbackuri = $parameters.callBackUri
    }
}

if ($callbackuri) {
    Invoke-WebRequest -Method POST -Uri $callbackuri -UseBasicParsing -Body (ConvertTo-Json $response) -ContentType "application/json"
}

# Stop the VM
Stop-AzVM -Name $vmName -ResourceGroupName $resourceGroupName -Force
