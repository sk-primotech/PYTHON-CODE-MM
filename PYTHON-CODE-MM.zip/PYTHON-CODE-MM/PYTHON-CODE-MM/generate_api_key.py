import random
import string

"""
This function generates a random API key for a user. You still need to 
manually add the API key to the database.
"""

def generate_api_key():
    # Generate a random 14-character string of digits and letters
    characters = string.ascii_letters + string.digits
    random_string = ''.join(random.choice(characters) for _ in range(30))

    # Combine the month and random string to form the API key
    api_key = f"MM-{random_string}"

    return api_key

if __name__ == "__main__":
    print(generate_api_key())
