import re
from dotenv import load_dotenv
import os
import pandas as pd
import sqlalchemy as sa

from datetime import datetime

load_dotenv()

def get_sqlalchemy_engine() -> sa.engine.base.Engine:
    """Get a SQLAlchemy engine for the database."""
    connection_string = os.getenv("PYODBC-CONNECTION")

    # create SQLAlchemy engine
    engine = sa.create_engine(f"mssql+pyodbc:///?odbc_connect={connection_string}")
    return engine

def get_facility_data(engine: sa.engine.base.Engine) -> pd.DataFrame:
    """Get facility data from the database."""
    # read facility data from database
    facility_data = pd.read_sql("""
        SELECT [FacilityID], [Year], [Month], SUM([TotalSpend]) as TotalSpend
        FROM 
            [ecri].[PriceGuide]
        GROUP BY 
            [FacilityID], 
            [Year], 
            [Month]""",
        engine)
    # convert to dataframe
    facility_data = pd.DataFrame(facility_data)
    return facility_data

def custom_month_year_sort(column):
    # Custom sort function to handle month-year format like 'Apr-21'
    try:
        return datetime.strptime(column, '%b-%y')
    except ValueError:
        return pd.NaT  # Return NaT for non-datetime values (like 'FacilityID')

def transform_facility_data(facility_data: pd.DataFrame) -> pd.DataFrame:
    """Transform the facility data to have month-year as columns."""
    month_mapping = {1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'May',
                     6: 'Jun', 7: 'Jul', 8: 'Aug', 9: 'Sep', 10: 'Oct',
                     11: 'Nov', 12: 'Dec'}
    # replace the month number with the month name
    facility_data['Month_Name'] = facility_data['Month'].map(month_mapping)

    # sort by year and month
    facility_data.sort_values(by=['Year', 'Month'], inplace=True, ascending=False)

    facility_data['MonthYear'] = facility_data['Month_Name'].astype(str) + '-' + (facility_data['Year']%2000).astype(str)

    # Pivot the table
    transformed_data = facility_data.pivot_table(
        index='FacilityID',
        columns='MonthYear',
        values='TotalSpend',
        aggfunc='sum'
    )

    # Reset the index to turn FacilityID back into a column
    transformed_data.reset_index(inplace=True)
    transformed_data.columns.name = None

    # Optional: fill NaN values with 0 or any other appropriate value
    # transformed_data.fillna(0, inplace=True)
    sorted_columns = sorted(transformed_data.columns[1:], key=custom_month_year_sort, reverse=True)
    transformed_data = transformed_data[['FacilityID'] + sorted_columns]
    return transformed_data

def check_spending_variations(data: pd.DataFrame) -> pd.DataFrame:
    """Check each facility's monthly spend against the average (excluding current month) and flag significant variations."""
    monthly_columns = [col for col in data.columns if re.match( r".*-\d{2}$", col)]
    print(monthly_columns)
    # Initialize the 'Flag' and 'Flagged Months' columns
    data['Flag'] = False
    data['Flagged Months'] = [[] for _ in range(len(data))]

    # Iterate over each row in the DataFrame
    for index, row in data.iterrows():
        months_to_look_at = []
        if row['Average'] < 100_000: #kiran decided this
            continue
        # Check each month's spend against the adjusted average
        for month in monthly_columns:  # Adjust column range as needed
            month_spend = row[month]
            # Exclude the current month's spend for calculating average and std
            other_months = pd.Series([row[col] for col in monthly_columns if col != month])
            average_spend = other_months.mean()
            stdev_spend = other_months.std()
            if stdev_spend > 0:
                # Check if the current month's spend deviates significantly
                if abs((month_spend-average_spend)/stdev_spend) >= 3:
                    months_to_look_at.append(month)
            else:
                print(row["FacilityID"], month, month_spend)

        # Update the row if there are months to look at
        if months_to_look_at:
            data.at[index, 'Flag'] = True
            data.at[index, 'Flagged Months'] = months_to_look_at

    print(monthly_columns)
    return data

def identify_outliers_iqr(data: pd.DataFrame) -> pd.DataFrame:
    """
    Identify outlier facilities based on IQR method.
    
    Parameters:
    - data: pd.DataFrame with columns for FacilityID and monthly spends.
    
    Returns:
    - pd.DataFrame with an additional 'Outlier' column indicating if the facility is an outlier.
    """
    # Select columns that match the pattern, the pattern is -YY
    monthly_columns = [col for col in data.columns if re.match( r".*-\d{2}$", col)]
    
    # Calculate Q1 (25th percentile) and Q3 (75th percentile) of the total spend
    Q1 = data[monthly_columns].quantile(0.25, axis=1)
    Q3 = data[monthly_columns].quantile(0.75, axis=1)

    # Calculate the Interquartile Range (IQR)
    IQR = Q3 - Q1

    # Determine outliers using the 1.5*IQR criteria
    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR
    
    # Flag facilities as outliers based on the total spend
    data['IQR_Outliers'] = False
    
        # Iterate over rows to check if any monthly spend is outside the bounds
    for index, row in data.iterrows():
        # Check if any spend is below the lower bound or above the upper bound for this facility
        is_outlier = any(row[monthly_columns] < lower_bound[index]) or any(row[monthly_columns] > upper_bound[index])
        # Update the 'IQR_Outlier' column
        data.at[index, 'IQR_Outlier'] = is_outlier
    
    return data

# if name == main
    
if __name__ == "__main__":
    engine = get_sqlalchemy_engine()
    try:
        facility_data = pd.read_csv("facility_data.csv")
    except Exception as _:
        facility_data = get_facility_data(engine)
        facility_data.to_csv("facility_data.csv")
    facility_data.sort_values(by=['Year','Month'], inplace=True, ascending=False)

    new_facility_data = transform_facility_data(facility_data)
    monthly_columns = [col for col in new_facility_data.columns if re.match( r".*-\d{2}$", col)]

    new_facility_data['Average'] = new_facility_data[monthly_columns].mean(axis=1)
    new_facility_data['Min'] = new_facility_data[monthly_columns].min(axis=1)
    new_facility_data['Max'] = new_facility_data[monthly_columns].max(axis=1)
    new_facility_data['Stdev'] = new_facility_data[monthly_columns].std(axis=1)
    new_facility_data['Value - Average'] = new_facility_data[monthly_columns[0]] - new_facility_data['Average']
    # Calculate z score for the 3rd columns (2nd index)
    new_facility_data['Z-Score'] = new_facility_data['Value - Average']/new_facility_data['Stdev']
    new_facility_data['Median'] = new_facility_data[monthly_columns].median(axis=1)
    new_facility_data['Average/Median'] = new_facility_data['Average']/ new_facility_data['Median'] 

    # absoulte value of z score
    new_facility_data['Z-Score_abs'] = new_facility_data['Z-Score'].abs()
    new_facility_data.sort_values(by=['Z-Score_abs'], inplace=True, ascending=False)
    new_facility_data.drop(columns=['Z-Score_abs'], inplace=True)
    new_facility_data[['Average','Min','Max','Stdev','Value - Average','Z-Score','Median', 'Average/Median',"FacilityID"]]

    rearrange_df = new_facility_data[['Average','Min','Max','Stdev','Value - Average','Z-Score','Median', 'Average/Median',"FacilityID"]].copy()

    for col in monthly_columns:
        if col not in rearrange_df.columns:
            rearrange_df[col] = new_facility_data[col]

    rearrange_df.to_csv("most_recent_month_facility_z_score.csv", index=False)

    flagged_data = check_spending_variations(rearrange_df)
    IQR_and_flagged_data = identify_outliers_iqr(flagged_data)

    IQR_and_flagged_data.to_csv("facility_outliers.csv", index=False)
