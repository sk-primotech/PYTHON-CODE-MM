import datetime
import os
import pandas as pd
import pyodbc
import requests
import xml.etree.ElementTree as ET
import zipfile
from dotenv import load_dotenv
from bs4 import BeautifulSoup
from time import time
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient, BlobClient ,ContainerClient

# load the environment variables
load_dotenv()

def get_dates() -> tuple[str,str,str,str,str]:
    today = datetime.datetime.now()
        # If today is Monday, set yesterday to last Friday.
    if today.weekday() == 0:
        yesterday = (today - datetime.timedelta(days=3)).strftime("%Y%m%d")
    else:  # If today is not Monday, just get yesterday
        yesterday = (today - datetime.timedelta(days=1)).strftime("%Y%m%d")

    first_of_month = today.replace(day=1).strftime("%Y%m%d")

    # Get the most recent Sunday.
    if today.weekday() == 6:  # If today is Sunday
        previous_sunday = today
    else:  # If today is not Sunday
        days_since_sunday = today.weekday() + 1  # The number of days since last Sunday
        previous_sunday = today - datetime.timedelta(days=days_since_sunday)
    previous_monday = (previous_sunday - datetime.timedelta(days=6)).strftime("%Y%m%d")
    previous_sunday = previous_sunday.strftime("%Y%m%d")
    today = today.strftime("%Y%m%d")

    return today,yesterday, first_of_month,previous_monday,previous_sunday

def get_gudid_data(url:str,folder:str) -> str:
    print(f"Downloading {folder}")
    if os.path.exists(folder + ".zip"):# check if the zipped folder exists
        print(f"folder {folder + '.zip' } already exists, skipping download")
    else:
        r = requests.get(url, allow_redirects=True)
        open(folder+".zip", 'wb').write(r.content)

    print(f"\nUnzipping {folder}")
    if os.path.exists(folder): # check if the unzipped folder exists
        print(f"folder {folder} already exists, skipping unzip")
    else:
        with zipfile.ZipFile(folder + ".zip", 'r') as zip_ref:
            zip_ref.extractall(folder)

    os.remove(folder + ".zip")

    return folder

def flatten_dict(d) -> dict:
    items = []
    for k, v in d.items():
        if isinstance(v, dict):
            items.extend(flatten_dict(v).items())
        else:
            items.append((k, v))
    return dict(items)

def recursive_dict(element) -> dict | str:
    return element.text if len(element) == 0 else {e.tag.split('}')[-1]: recursive_dict(e) for e in element}

def process_xml(file: str, to_dataframe: bool = True, columns_needed:list = []) -> pd.DataFrame | list[dict]:
    namespaces = {'ns': 'http://www.fda.gov/cdrh/gudid'}  # add more as needed
    etree = ET.parse(file)  # create an ElementTree object 

    root = etree.getroot()

    data = []

    for device in root.findall('.//ns:device', namespaces):
        original_dict = flatten_dict(recursive_dict(device))
        file = {k: original_dict[k] for k in columns_needed if k in original_dict}

        data.append(file)

    return pd.DataFrame(data) if to_dataframe else data

def get_full_delimited_data(url,columns_needed:list, save_file_name:str) -> pd.DataFrame:
    # Download the file
    zipped_file: str = 'data/'+url.split('/')[-1]
    folder: str = zipped_file[:-4]
    response = requests.get(url)
    print(f'Downloading {url}')
    # Save the file
    with open(zipped_file, 'wb') as file:
        file.write(response.content)

    if os.path.exists(folder): # check if the unzipped folder exists
        print(f"folder {folder} already exists, skipping unzip")
    else:
        with zipfile.ZipFile(zipped_file, 'r') as zip_ref:
            zip_ref.extractall(folder)

    dataframes: dict[str,pd.DataFrame] = {}
    folder_needed = ['device', 'gmdnTerms', 'identifiers', 'productCodes']
    try:
        # loop through the files in the txt folder 
        for file in os.listdir(folder):
            if file[:-4] in folder_needed:
                print(f"\nLoading {file[:-4]} into dataframe")
                dataframes[file[:-4]] = pd.read_csv(folder + "/" + file, sep="|", header=0, low_memory=False)
                    
                # check duplicates for dataframes['productCodes']
                dataframes[file[:-4]].drop_duplicates(inplace=True)
            os.remove(folder + "/" + file)
    except Exception as e:
        print(f"Error loading {folder} into dataframe: {e}")
    os.rmdir(folder)

    # Join gmdnTerms dataframe, identifiers dataframe to device dataframe on PrimaryDI
    dataframes['device'] = dataframes['device'].merge(dataframes['gmdnTerms'], how='left', on='PrimaryDI')
    dataframes['device'] = dataframes['device'].merge(dataframes['identifiers'], how='left', on='PrimaryDI')
    total = dataframes['device'].merge(dataframes['productCodes'], how='left', on='PrimaryDI')

    # Only keep the columns we need
    total = total[columns_needed]
    total.drop_duplicates(inplace=True)
    #overwrite the files
    total.to_csv(save_file_name, index=False)

    return total

def get_rss_feed(rss_url:str = 'https://accessgudid.nlm.nih.gov/download.rss',update_type:str='weekly_update', latest_update:bool=False, folder = 'data/') -> list[str]:
    '''
    Downloads the latest GUDID data from the RSS feed.
    
    Parameters
    ----------
    rss_url : str
        The URL of the RSS feed. Defaults to 'https://accessgudid.nlm.nih.gov/download.rss'.
    update_type : str
        The type of update to download. Must be one of 'daily_update','weekly_update','monthly_update', 'full_release'. Defaults to 'weekly_update'.
    latest_update : bool
        If True, only the latest update will be downloaded. Defaults to False.
    folder : str
        The folder where the downloaded zip file will be saved. Defaults to 'data/'. 
    '''
    file_names = []
    # Check that the update_type is valid
    if update_type not in ['daily_update','weekly_update','monthly_update']:
        raise ValueError(f"update_type must be one of 'daily_update','weekly_update','monthly_update'")

            
    # Get the RSS feed
    response = requests.get(rss_url)

    # Parse the XML content with BeautifulSoup
    soup = BeautifulSoup(response.content, 'xml')

    # Find all <item> elements in the XML content
    items = soup.find_all('item')

    # Search for the latest item of the required type
    for item in items:
        # Check if the title indicates the right type of release
        if update_type in item.title.text:
            print(f"Found {update_type} update")
            # Get the URL of the zip file
            zip_url = item.enclosure['url']

            # Get the name of the zip file
            zip_name = os.path.basename(zip_url)

            # Download the file
            response = requests.get(zip_url)
            print(f'Downloading {zip_url}')
            # Save the file
            with open(folder+zip_name, 'wb') as file:
                file.write(response.content)

            print(f'Downloaded {folder+zip_name}')

            file_names.append(folder+zip_name)
            # If we only want the latest update, stop after the first one
            if latest_update:
                return file_names
    return file_names

def daily_update(daily_file:str, gudid_df):
    daily_df = process_xml(daily_file)

    # Find the rows where 'deviceId' is duplicated
    # pd.set_option('display.max_columns', None)

    print(f"Daily file columns: {daily_df.columns}")
    duplicate_rows = daily_df[daily_df.duplicated(subset='deviceId', keep=False)]
    for idx, rows in duplicate_rows.groupby('deviceId'):
        print(rows[["publicDeviceRecordKey",'publicVersionStatus',"deviceId","versionModelNumber", "catalogNumber"]])
        columns = []
        for col in duplicate_rows.columns:

            if not (rows[col].nunique() == 1):
                columns.append(col)
        print(rows[columns])
    # Print the duplicate rows
    # print(duplicate_rows.iloc[:, 8:].sort_values('deviceId'))
    # print(f"There are {num_duplicates} duplicate rows based on the deviceId column.")

    # need all the columns from the gudid_df and publicVersionStatus from the daily_df
    total_columns = list(gudid_df.columns)
    total_columns.append('publicVersionStatus')
    total_columns.remove('PrimaryDI')
    daily_df = daily_df[total_columns]
    daily_df.drop_duplicates(inplace=True,keep='first')
    # Separate new and updated rows
    new_rows = daily_df[daily_df['publicVersionStatus'] == 'New']
    update_rows = daily_df[daily_df['publicVersionStatus'] == 'Update']

    # 'publicDeviceRecordKey' is the unique identifier column for the records
    key_column = 'deviceId'

    gudid_df.set_index(key_column, inplace=True)
    update_rows.set_index(key_column, inplace=True)

    # Then perform the update operation
    gudid_df.update(update_rows)

    # Reset the index
    gudid_df.reset_index(inplace=True)

    # Append the new rows
    # gudid_df = gudid_df.append(new_rows, ignore_index=True)
    gudid_df = pd.concat([gudid_df, new_rows], ignore_index=True)
    gudid_df.drop(columns=['publicVersionStatus'], inplace=True)
    return gudid_df

def azure_blob_upload(account_url: str, container_name: str, source_file_path: str, blob_name: str) -> None:
    try:
        # Get a credential using the DefaultAzureCredential
        credential = DefaultAzureCredential()

        blob_service_client = BlobServiceClient(account_url=account_url, credential=credential)

        # Get the container client
        container_client = blob_service_client.get_container_client(container_name)

        # Get blob client
        blob_client = container_client.get_blob_client(blob_name)

        # Upload the file
        with open(source_file_path, 'rb') as data:
            print(f"Uploading {source_file_path} to blob storage as blob {blob_name}")
            blob_client.upload_blob(data, overwrite=True)
        print(f"File {source_file_path} uploaded to blob storage as blob {blob_name}")

    except Exception as e:
        print(f"An exception occurred: {e}")

if __name__ == '__main__':
    gudid_site = 'https://accessgudid.nlm.nih.gov'
    today,yesterday, first_of_month,previous_monday,previous_sunday = get_dates()
    columns_needed = ["publicDeviceRecordKey",'PrimaryDI','deviceId', 'deviceIdIssuingAgency', 'gmdnPTName', 'brandName', 'versionModelNumber', 'catalogNumber', 'companyName', 'deviceDescription', 'productCode', 'productCodeName']
    source_file_path = "data/gudid.csv"
    today = first_of_month # TODO: REMOVE THIS LINE AFTER TESTING
    
    # if today is the first of the month, download the full delimited file
    # if today == first_of_month:
    full_delimited_url = f'https://accessgudid.nlm.nih.gov/release_files/download/AccessGUDID_Delimited_Full_Release_{first_of_month}.zip' #gudid_site + f'/release_files/download/AccessGUDID_Delimited_Full_Release_{first_of_month}.zip' #

    gudid_df = get_full_delimited_data(full_delimited_url,columns_needed,source_file_path) # TODO: UNCOMMENT THIS LINE AFTER TESTING


    # To Blob Storage
    account_url = os.getenv("GUDID_BLOB_ACCOUNT_URL")
    container_name = os.getenv("GUDID_CONTAINER_NAME")
    blob_name = f"gudid_{first_of_month}.csv"
    start_time = time()
    azure_blob_upload(account_url, container_name, source_file_path, blob_name)
    print(f"Time taken to upload {blob_name} to blob storage: {time() - start_time} seconds")
        # if redo_update == True:
        #     zipped_files = get_rss_feed(update_type='weekly_update', latest_update=False)
        #     gudid_df.to_csv("data/gudid.csv",index=False)
    # else:
    #         # if today is Friday, download the weekly file
    #     if today == previous_sunday:
    #         zipped_files = get_rss_feed(update_type='weekly_update', latest_update=False)

    #     # if today is not monday or the first of the month, download the daily file
    #     else:
    #         [zipped_file] = get_rss_feed(update_type='daily_update', latest_update=True)
            
    #     # data_folder = get_gudid_data(url,folder)
    #     gudid_df = pd.read_csv("data/gudid.csv", low_memory=False)
    #     gudid_df.drop_duplicates(inplace=True,subset=['publicDeviceRecordKey'])