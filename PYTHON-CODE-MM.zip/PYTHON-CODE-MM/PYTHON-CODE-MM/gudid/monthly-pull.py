import argparse
import os
import logging
from logging.handlers import RotatingFileHandler
import datetime
import io
import pandas as pd
import requests
import zipfile
from time import time, sleep
from azure.identity import ManagedIdentityCredential, DefaultAzureCredential
from azure.mgmt.datafactory import DataFactoryManagementClient
from azure.storage.blob import BlobServiceClient


class MonthlyPull:
    def __init__(
        self,
        azure_resource: bool,
        log_path: str = os.getcwd(),
        overrideDay: int = None,
    ):
        """
        Initialize the MonthlyPull class.

        Args:
            log_path (str, optional): Path where the log file will be created. Defaults to the current working directory.
            overrideDay (int, optional): Override the day of the month for testing purposes. Defaults to None.
        """
        self.overrideDay = overrideDay
        self.logger = self.setup_logger(log_path)
        self.credentials = (
            ManagedIdentityCredential() if azure_resource else DefaultAzureCredential()
        )
        self.GO_BACK = 2  # Number of days to go back from the current date
        self.save_file_path = "gudid.csv"  # Path to save the downloaded CSV file
        self.columns_needed = [
            "publicDeviceRecordKey",
            "PrimaryDI",
            "deviceId",
            "deviceIdIssuingAgency",
            "gmdnPTName",
            "brandName",
            "versionModelNumber",
            "catalogNumber",
            "companyName",
            "deviceDescription",
            "productCode",
            "productCodeName",
            "pkgQuantity",
        ]

    def setup_logger(self, log_path: str) -> logging.Logger:
        """
        Set up logging configuration.
        """
        # Create a rotating file handler to log to 'app.log'
        file_handler = RotatingFileHandler(
            f"{log_path}/monthly-pull.log", maxBytes=10000, backupCount=5
        )
        file_handler.setLevel(logging.INFO)

        # Create a console handler to log to the console
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)

        # Create a formatter and add it to both handlers
        formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # Get the root logger and configure it
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

        # Set the logging level for the Azure logger to WARNING
        azureLogger = logging.getLogger("azure")
        azureLogger.setLevel(logging.WARNING)
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

        return logger

    def get_full_delimited_data(self) -> str:
        """
        Download and process the full delimited data from the GUDID website.

        Returns:
            str: File name to save to file to in Azure Blob Storage.
        """
        today = datetime.datetime.now()
        today = today.replace(day=self.overrideDay) if self.overrideDay else today
        day_to_test = None

        # Check for the last two days and stream the download
        for day in range(
            today.day,
            0 if today.day <= self.GO_BACK - 1 else today.day - self.GO_BACK,
            -1,
        ):
            day_to_test = today.replace(day=day).strftime("%Y%m%d")
            full_delimited_url = f"https://accessgudid.nlm.nih.gov/release_files/download/AccessGUDID_Delimited_Full_Release_{day_to_test}.zip"
            self.logger.info(
                f"Downloading and processing data from {full_delimited_url}"
            )

            with requests.get(full_delimited_url, stream=True) as response:
                if today.day - self.GO_BACK + 1 == day and response.status_code != 200:
                    response.raise_for_status()
                elif response.status_code != 200:
                    self.logger.error(f"File not found for {full_delimited_url}")
                    continue

                self.logger.info(
                    f"Starting download from {full_delimited_url} to {self.save_file_path}"
                )

                # Read zipped content directly from the response
                with zipfile.ZipFile(io.BytesIO(response.content)) as zip_ref:
                    folder_needed = [
                        "device",
                        "gmdnTerms",
                        "identifiers",
                        "productCodes",
                    ]
                    dataframes = {}

                    for file in zip_ref.namelist():
                        # Extracting file name without extension
                        file_name = file.split("/")[-1][:-4]
                        if file_name in folder_needed:
                            self.logger.info(f"Loading {file_name} into dataframe")
                            # Read the specific file from zipped content
                            with zip_ref.open(file) as f:
                                # Load the file content into a DataFrame
                                dataframes[file_name] = pd.read_csv(
                                    f, sep="|", header=0, low_memory=False
                                )
                                dataframes[file_name].drop_duplicates(inplace=True)

                if response.status_code == 200:
                    break

        # Merge the DataFrames
        total = dataframes["device"]
        for key in ["gmdnTerms", "identifiers", "productCodes"]:
            if key in dataframes:
                total = total.merge(dataframes[key], how="left", on="PrimaryDI")

        # Filter the columns needed
        total = total[self.columns_needed]
        total.drop_duplicates(inplace=True)

        # Save the final DataFrame
        total.to_csv(
            self.save_file_path,
            index=False,
            encoding="utf-8",
            sep=",",
            quotechar='"',
            doublequote=False,
            escapechar="\\",
        )

        return day_to_test

    def azure_blob_upload(
        self,
        account_url: str,
        container_name: str,
        source_file_path: str,
        blob_name: str,
    ) -> None:
        """
        Upload a file to an Azure Blob Storage container.

        Args:
            account_url (str): The URL of the Azure Blob Storage account.
            container_name (str): The name of the container where the file will be uploaded.
            source_file_path (str): The path of the file to be uploaded.
            blob_name (str): The name of the blob (file) in the container.
        """
        blob_service_client = BlobServiceClient(
            account_url=account_url, credential=self.credentials
        )

        # Get the container client
        container_client = blob_service_client.get_container_client(container_name)

        # Get blob client
        blob_client = container_client.get_blob_client("full_release/" + blob_name)

        # Upload the file
        with open(source_file_path, "rb") as data:
            self.logger.info(
                f"Uploading {source_file_path} to blob storage as blob {blob_name}"
            )
            blob_client.upload_blob(data, overwrite=True)

        self.logger.info(
            f"File {source_file_path} uploaded to blob storage as blob {blob_name}"
        )

        # remove the file
        os.remove(source_file_path)
        self.logger.info(f"File {source_file_path} removed from local storage")

    def trigger_data_factory(
        self,
        subscription_id: str,
        resource_group: str,
        data_factory_name: str,
        pipeline_name: str,
        parameters: dict,
    ) -> None:
        """
        Trigger an Azure Data Factory pipeline.

        Args:
            subscription_id (str): The ID of the Azure subscription.
            resource_group (str): The name of the resource group containing the Data Factory.
            data_factory_name (str): The name of the Data Factory.
            pipeline_name (str): The name of the pipeline to be triggered.
            parameters (dict): A dictionary of parameters to pass to the pipeline.
        """
        adf_client = DataFactoryManagementClient(self.credentials, subscription_id)
        response = adf_client.pipelines.create_run(
            resource_group, data_factory_name, pipeline_name, parameters=parameters
        )
        self.logger.info(f"Pipeline triggered with run ID: {response.run_id}")

    def run(self) -> None:
        """
        Main function to download, process, upload, and trigger the pipeline.
        """
        if os.path.exists(self.save_file_path):
            os.remove(self.save_file_path)
        
        save_to = self.get_full_delimited_data()
        self.logger.info(f"Finished downloading to {self.save_file_path}")

        # To Blob Storage
        account_url = "https://medminedata.blob.core.windows.net/"
        container_name = "gudid"

        blob_name = f"{save_to}.csv"
        start_time = time()

        self.azure_blob_upload(
            account_url, container_name, self.save_file_path, blob_name
        )
        self.logger.info(
            f"Time taken to upload {blob_name} to blob storage: {(time() - start_time)/60} minutes"
        )

        pipeline_parameters = {
            "schemaName": "mm",
            "tableName": "gudid",
            "Container": container_name,
            "Directory": "full_release",
            "FileName": blob_name,
        }

        # Add your subscription ID, resource group, data factory, and pipeline names here
        subscription_id = "3b90ddcb-53ec-4263-92ce-84002c61fc5d"
        resource_group = "medminellc"
        data_factory_name = "SQLServerArchiveTables"
        pipeline_name = "Gudid_BlobToAzureSQL"

        # Trigger the data factory pipeline
        self.trigger_data_factory(
            subscription_id,
            resource_group,
            data_factory_name,
            pipeline_name,
            pipeline_parameters,
        )
        self.logger.info("------- Function executed successfully ----------")
        return True

if __name__ == "__main__":
    # Create an argument parser
    parser = argparse.ArgumentParser(description="Monthly Pull Script")

    # Add arguments
    parser.add_argument(
        "--log-path",
        type=str,
        default=os.getcwd(),
        help="Path to log file",
        required=False,
    )
    parser.add_argument(
        "--override-days",
        type=int,
        default=None,
        help="Number of days to override",
        required=False,
    )
    parser.add_argument(
        "--azure-resource",
        default=False,
        action=argparse.BooleanOptionalAction,
        help="Check if running on Azure Resource (Uses Managed Identity for authentication)",
        required=False,
    )

    # Parse the arguments
    args = parser.parse_args()

    # Access the arguments
    log_path = args.log_path
    override_days = args.override_days
    azure_resource = args.azure_resource

    success = False
    RETRY_INTERVAL = 43200  # Retry every 12 hours

    # create an instance of the class and run the function
    monthly_pull = MonthlyPull(
        azure_resource, log_path=log_path, overrideDay=override_days
    )
    while not success:
        try:
            monthly_pull.run()
            success = True
        except Exception as e:
            monthly_pull.logger.error(f"An exception occurred: {e}")
            sleep(RETRY_INTERVAL)  # Sleep for 12 hours