from azure.identity import DefaultAzureCredential
from azure.mgmt.storage import StorageManagementClient
from azure.mgmt.storage.models import ManagementPolicyFilter, ManagementPolicy, ManagementPolicyRule, ManagementPolicyDefinition, ManagementPolicyAction, ManagementPolicyBaseBlob, ManagementPolicySnapShot, DateAfterModification, ManagementPolicySchema

def main(name: str, storage_account_name: str, resource_group_name: str, subscription_id: str, filters: list = None):
    print(f"Adding Lifecycle Management Rule with name: {name}")
    # Authenticate with Azure
    credential = DefaultAzureCredential()

    # Create a StorageManagementClient
    client = StorageManagementClient(credential, subscription_id)

    # Retrieve current policy
    current_policy = None
    try:
        current_policy = client.management_policies.get(resource_group_name, storage_account_name, 'default')
    except Exception as e:
        print(f"Error:\n{e}")
        print("Creating new policy")
        current_policy = ManagementPolicy(policy=ManagementPolicySchema(rules=[]))

    # Define the new rule
    rule = ManagementPolicyRule(
        enabled=True,
        name=name,
        type="Lifecycle",
        definition=ManagementPolicyDefinition(
            actions=ManagementPolicyAction(
                base_blob=ManagementPolicyBaseBlob(
                    tier_to_cold=DateAfterModification(days_after_creation_greater_than=7),
                    tier_to_archive=DateAfterModification(days_after_creation_greater_than=90),
                )
            ),
            filters=ManagementPolicyFilter(blob_types=["blockBlob"], prefix_match=filters)
        )
    )

    current_policy.policy.rules.append(rule)

    # Update the policy with the new rule
    client.management_policies.create_or_update(resource_group_name, storage_account_name, 'default', current_policy)

    print("Lifecycle Management Rule added successfully.")

if __name__ == "__main__":
    """
    Filter blobs by name or first letters. To find items in a specific container, enter the name of the container followed by a 
    forward slash, then the blob name or first letters. For example, to show all blobs starting with "a", type: "mycontainer/a".
    """
    data = {
        "name": "",
        "filters": [],
        "storage_account_name" : "",
        "resource_group_name" : "",
        "subscription_id": ""
    }
    main(data.get("name"), data.get("storage_account_name"), data.get("resource_group_name"), data.get("subscription_id"), data.get("filters"))
