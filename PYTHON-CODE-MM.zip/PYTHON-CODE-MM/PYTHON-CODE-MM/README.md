# MedMineLLC

## Environment Setup:
### Python Setup

1. Download Python 3.11.4 [Here](https://www.python.org/downloads/release/python-3114/)
2. Verify the installation by running `python --version` or `python3 --version`
3. Create a virtual environment by running `python -m venv medmine-env`
4. Activate the virtual environment by running:
    - Windows: `source medmine-env/Scripts/activate`
    - MacOS/Linux: `source medmine-env/bin/activate`
5. Update pip by running `python -m pip install --upgrade pip`
6. Run `pip install -r requirements.txt`
7. Once you're done working, deactivate the virtual environment by running `deactivate`

### Node Setup
1. Download Node.js v18.19.0 (and latest for npm) [Here](https://nodejs.org/en/download/)
    - I highly recommend using [Node Version Manager](https://github.com/nvm-sh/nvm) to manage your Node.js versions. This will allow you to easily switch between Node.js versions. You do not need to install Node.js if you use NVM, it will install it for you.
2. Verify the installation by running `node --version` and `npm --version`

### SQL Server Driver (Version 18)
You will need to also download ODBC drivers for SQL Server [Here](https://learn.microsoft.com/en-us/sql/connect/odbc/download-odbc-driver-for-sql-server?view=sql-server-ver16)

### Azure CLI
1. Download the [Azure CLI](https://learn.microsoft.com/en-us/cli/azure/install-azure-cli#install)
2. Verify the installation by running `az --version`
3. Login to your Azure account by running `az login`

### Docker
1. Download Docker Desktop [Here](https://www.docker.com/products/docker-desktop/)
2. Verify the installation by running `docker --version`

### Pulling Environment Variables:

1. Set up Azure CLI and login to your Azure account.
    * You will need the role "Key Vault Secrets User" to access the key vault.
2. Navigate to the `read_env.py` file in the `MedMineLLC` directory.
3. run the command `python read_env.py` in the terminal.
4. This will create a `.env` file in the `MedMineLLC` directory with the necessary environment variables.

## Directory Descriptions
| Folder                    | Description |
|---------------------------|-------------|
| /blob_storage             | This script authenticates with Azure using default credentials and updates or creates a lifecycle management policy for an Azure storage account, adding a new rule to move blobs to cooler storage tiers based on their age. |
| /excel_refresh            | There is a an API in this folder that is deployed on the Excel Refresh VM. The point of this API is to be able to refresh the excel files through an API rather than manually updating them. |
| /facility_report          | The Python script processes facility spending data by retrieving it from a SQL database, transforming it into a pivot table with month-year columns, and identifying significant spending variations and outliers using statistical methods. It then exports the processed and flagged data to CSV files for further analysis. |
| /gudid                    | This folder contains the `monthly-pull.py` file that runs on the MainServer VM. This file pulls data from the `accessgudid.nlm.nih.gov` website. |
| /logging                  | Some programs output their logs to this folder. It's just a placement folder. |
| /manual_refresh           | Contains a file that allows someoe to run a command on any VM without opening up the VM. |
| /Mapping_data             | Contains an API and numerous Python files that are used to move data from Mongo to SQL DB |

### Other Files
| File                            | Description                                                                                                                                                             |
|---------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| .env.example                    | This file contains the environment variables that are needed to run the application.                                                                                    |
| requirements.txt                | This file contains the python packages that are needed to run the application.                                                                                          |
| read_env.py                     | This file is used to pull the environment variables from the Azure Key Vault and create a .env file in the MedMineLLC directory.                                        |
| matches_to_excel.ipnb           | idk                                                                                                                                                                     |
| .gitignore                      | This file contains the files that are ignored by git.                                                                                                                   |
| generate_api_key.py             | This file is used to generate an API keys for our APIs. Our API keys are currently hard coded in the API files (db.py), so this will need to be updated once Microsoft Entra is set up. |
| map_data_cluster_automation.ps1 | This powershell script is used on the Azure Automation account (automatic-mapping-automation) to start the VM, run the python script, and stop the VM. The script will finish when the python script finishes running. |


